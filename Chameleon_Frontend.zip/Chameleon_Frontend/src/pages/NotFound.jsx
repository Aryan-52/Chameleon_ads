import React from "react";
export default function NotFound(){
  return (
    <div style={{padding:40}}>
      <h2>Page not found</h2>
      <p>The page you're looking for doesn't exist.</p>
    </div>
  );
}
